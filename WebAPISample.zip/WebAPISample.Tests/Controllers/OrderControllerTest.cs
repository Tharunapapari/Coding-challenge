﻿using System;
using System.Web.Http;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WebAPISample.Models;
using WebAPISample.Controllers;
using System.Web.Http.Results;
using System.Net.Http;
using System.Web.Http.Hosting;

namespace WebAPISample.Tests.Controllers
{
    [TestClass]
    public class OrderControllerTest
    {
        [TestMethod]
        public void GetCustomerRecordNotFound()
        {
            // Arrange
            var controller = new OrderController();
            // Act
            IHttpActionResult actionResult = controller.GetCustomerOrder("1245");
            // Assert
            Assert.IsInstanceOfType(actionResult, typeof(NotFoundResult));
        }

        [TestMethod]
        public void GetCustomerRecordFound()
        {
            // Arrange
            var controller = new OrderController();

            // Act
            IHttpActionResult actionResult = controller.GetCustomerOrder("12345");
            var contentResult = actionResult as OkNegotiatedContentResult<Order>;
            // Assert
            Assert.IsNotNull(contentResult);
            //Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual("12345", contentResult.Content.customerId);
        }

        [TestMethod]
        public void CreateOrder()
        {
            var order = GetTestOrder();
            var controller = new OrderController();

            IHttpActionResult result = controller.CreateOrder(order);
            Assert.IsInstanceOfType(result, typeof(OkResult));
        }

        [TestMethod]
        public void CreateOrderWithInvalidProductID()
        {
            var controller = new OrderController();

            var order = new OrderViewModel()
            {
                customerId = "45678",
                items = new List<Item>() {
                    new Item{productId="8ed0e6aaaf7",quantity=1 },
                    new Item{productId="c0258525",quantity=3 },
                    new Item{productId="0a207870",quantity=2 }
                }
            };

            IHttpActionResult result = controller.CreateOrder(order);
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
        }


        private OrderViewModel GetTestOrder()
        {
            var testOrder = new OrderViewModel();
            testOrder=new OrderViewModel { customerId = "12345", items = new List<Item>() {
                new Item{productId="8ed0e6f7",quantity=1 },
                new Item{productId="c0258525",quantity=3 },
                new Item{productId="0a207870",quantity=2 }
            } };
            
            return testOrder;
        }


    }
}
