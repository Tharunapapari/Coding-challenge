﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebAPISample.Models;

namespace WebAPISample.Controllers
{
    [RoutePrefix("api/Order")]
    public class OrderController : ApiController
    {
        string liteDBPath = @"G:\Practice\WebAPISample\WebAPISample\Database\MyData.db";
        public List<Product> GetProducts()
        {
            IEnumerable<Product> products = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://petstoreapp.azurewebsites.net/api/");
                //HTTP GET
                var responseTask = client.GetAsync("products");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<Product>>();
                    readTask.Wait();

                    products = readTask.Result;
                }
                else //web api sent error response 
                {
                    //log response status here..
                    products = Enumerable.Empty<Product>();
                    //ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }

            return products.ToList();
        }

        [HttpGet]
        [Route("Get")]
        public IHttpActionResult GetOrders()
        {
            var result = new List<Order>();
            using (var db = new LiteDatabase(liteDBPath))
            {
                var data = db.GetCollection<Order>("Orders");
                var orders = data.FindAll();
                foreach(Order od in orders)
                {
                    result.Add(od);
                }
            }
            var resp = new { data =result};
            return Ok(resp);
        }

        [HttpGet]
        [Route("GetCustomerOrder")]
        public IHttpActionResult GetCustomerOrder(string customerID)
        {
            var result = new Order();
            using (var db = new LiteDatabase(liteDBPath))
            {
                var data = db.GetCollection<Order>("Orders");
                var orders = data.Find(x=>x.customerId == customerID).FirstOrDefault();
                if (orders == null)
                    return NotFound();
                result = orders;
            }
            //var resp = new { data = result };
            return Ok(result);
        }

        [HttpPost]
        [Route("CreateOrder")]
        public IHttpActionResult CreateOrder(OrderViewModel request)
        {
            if (request == null)
                return BadRequest(JsonConvert.SerializeObject(new { Data = "Invalid Request" }));
            // Open data file (or create if not exits)
            using (var db = new LiteDatabase(liteDBPath))
            {
                //Get Products
                List<Product> products = GetProducts();
                // Get customer collection
                var col = db.GetCollection<Order>("Orders");

                foreach(var item in request.items)
                {
                    var product = products.FirstOrDefault(x => x.Id == item.productId);
                    if (product !=null)
                    {
                        var order = new Order() { customerId = request.customerId, productId = item.productId, quantity = item.quantity,
                        cost = item.quantity * product.Price };
                        col.Insert(order);
                    }
                    else
                    {
                        //Product not found
                        return NotFound();
                    }
                }
            }

            return Ok();
        }
    }
}