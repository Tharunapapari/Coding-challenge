﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebAPISample.Models;

namespace WebAPISample.Controllers
{
    [RoutePrefix("api/Product")]
    public class ProductController : ApiController
    {
        [HttpGet]
        [Route("GetProducts")]
        public List<Product> GetProducts()
        {
            IEnumerable<Product> products = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://petstoreapp.azurewebsites.net/api/");
                //HTTP GET
                var responseTask = client.GetAsync("products");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<Product>>();
                    readTask.Wait();

                    products = readTask.Result;
                }
                else //web api sent error response 
                {
                    //log response status here..
                    products = Enumerable.Empty<Product>();
                    //ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }

            return products.ToList();
        }
    }
}