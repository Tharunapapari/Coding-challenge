﻿using LiteDB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebAPISample.Models
{
    public class OrderViewModel
    {
        public string customerId { get; set; }
        public List<Item> items { get; set; }

    }

    public class Item
    {
        public string productId { get; set; }
        public int quantity { get; set; }
    }

    public class Order
    {
        [BsonId]
        public int orderId { get; set; }
        public string customerId { get; set; }
        public string productId { get; set; }
        public int quantity { get; set; }
        public double cost { get; set; }
    }
}